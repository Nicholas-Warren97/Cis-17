/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 *
 * File:   main.cpp 
 * Author: Nicholas Warren
 *
 *  * Created on June 23, 2022, 7:09 PM
 * Purpose C++ Template - To be used in all future Assignments 
 */
// System Libraries

//System Level Libraries
#include <iostream>  //Input-Output Library
using namespace std;

//User Defined Libraries

//Global Constants, not Global Variables
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between
//systems of units!

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    cout << "Hello World \n";
    return 0;
}